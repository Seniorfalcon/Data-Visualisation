# Titanic Survival Data Set
## by Ahmed Kamel Hassan


## Dataset

>  the dataset contain the informations about Titanic passengers like ( id, name, sex, age, passenger class, wheather passenger survived or not, Number of Siblings/Spouses/Parents/Children Aboard, Port of Embarkation, Cabin number )

> the data sourse is https://github.com/awesomedata/awesome-public-datasets/tree/master/Datasets

> at first i had make some explorations to see how structured my data using some functions like ( shape, info, describe, null, ... ) to make overview about my data.


## Summary of Findings

> Most of the ship's passengers died.
> Most of the passengers do not have any relatives on board.
> Most of the passengers were young people, and the average age of the passengers was about 30 years old.
> Most of the passengers were in the third class
> The number of men is higher than women
> for females passengers, the number of survived was more than dead, but for males, the number of survived were less than dead.
> as class increased (1> 2> 3) the ages of passengers included increased
> we can note that number of not survived passengers increased as passenger class decrease ( class 3 less than 2 less than 1 ), class 1 is the best class and class 3 is the worst. 
> as class increased ( 1>2>3 ) mean age of passengers who survived ( and also not survived ) increased.
> in general mean age of passengers who dead ( in each class ) heigher that the mean age of survived passengers
> the mean age of male passengers who survived approximately equal to that for female, but for not survived passengers, the mean age for male higher w.r.t females (there is no direct relationship ), in general mean age of passengers who dead ( in each class ) heigher that the mean age of survived passengers.


## Key Insights for Presentation

> we can note that number of dead passengers increased as passenger class decrease ( class 3 less than 2 less than 1 ), class 1 is the best class and class 3 is the worse In spite of mean age of passengers in each class increased as the  passenger class increased

> number of survived females in each class is higher than survived males, in spite of the number of females in each class in less than males
